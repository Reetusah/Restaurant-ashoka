<html>
    <body>
        <form action="update.php" method="GET"><br>
        <?php
        $a=$_GET['id'];
        $conn=mysqli_connect('localhost','root','','ashoka');
      $q="delete from dummycart where foodname='$a'";
      $rs=mysqli_query($conn,$q);
      if($rs){
        echo"
        <script>window.location='cart.php'</script>
           
            ";}
            else{
                echo"error";
            }
            ?>
            
        </form>
        </body>
    </body>
</html>