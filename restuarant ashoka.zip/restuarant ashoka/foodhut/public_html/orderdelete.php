<html>
    <body>
        <form action="orderupdate.php" method="GET"><br>
        <?php
        $a=$_GET['id'];
        $conn=mysqli_connect('localhost','root','','ashoka');
      $q="delete from orderinfo1 where sno='$a'";
      $rs=mysqli_query($conn,$q);
      if($rs){
        echo"
        <script>window.location='aorder.php'</script>
           
            ";}
            else{
                echo"error";
            }
            ?>
            
        </form>
        </body>
    </body>
</html>