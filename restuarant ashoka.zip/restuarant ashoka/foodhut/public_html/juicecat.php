<html>
  <style>
    
    body{
background-image:url("bac.jpg");
background-size:1700px 800px;
background-repeat:no-repeat;}

ul {background-color:rgb(46, 43, 43);
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  
}
li {
  float: left;
}

li a {
  display: block;
  color: white;
  font-size:20px;
 padding: 25px 0px;
  text-decoration: none;
  margin-left:30px;
  text-decoration:underline;
}

li a:hover {
  
  color:rgb(223, 52, 86);
}
            
        
.logo{width:50px;
    height:50px; background-image:url('logo.jpg');
    background-size: 50px 50px;
    border-radius: 360px;
    margin-left: 5px;
    margin-top: 10px;}
.x{position:absolute;
background-color:black;
box-shadow:3px 5px 8px 10px white;
float:left;
width:500px;
height:400px;
top:130px;
left:350px;
opacity:0.6;}
.z{position:absolute;
    color:white;
width:300px;
height:0px;
top:150px;
left:420px;}
.t{color:black;
font-size:40px;
font-family: cursive;


margin-left:350px;
margin-top:10px;
padding:10px 100px;
}
.s{
    color:black;
    font-size: 25px;
    font-family: cursive;
    margin-left:350px;
}
.w{
width:250px;
color:white;
font-size:20px;
background:transparent;
border:none;
border-bottom-style:solid;
border-bottom-color:black;
border-bottom-width:5px;
margin-left:300px;
margin-top:10px;}
.fc{
    margin-left:40px;
     margin-top:150px;
    color:white;
    font-family:cursive ;
    font-size:29px;
}
.p{

    margin-left: 350px;
}

           
.v{
color:white;
font-weight:bold;}
.n{
    background-color: red;
    color:white;
    border-radius:10px;
    height:50px;
    width:100px;
    font-size:15px;
}
.m{color:black;}
.form-control {
  display: block;
  width: 100%;
  height: calc(1.5em + 0.8rem + 2px);
  padding: 0.4rem 0.78rem;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  color:black;
  background-color: white;
  background-clip: padding-box;
  border: 1px solid #495057;
  border-radius: 0.2rem;
  -webkit-transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}


  .form-control {
    -webkit-transition: none;
    transition: none;
  }
  .form-control-lg {
  height: calc(1.5em + 1.6rem + 2px);
  padding: 0.8rem 1.6rem;
  font-size: 1.25rem;
  line-height: 1.5;
  border-radius: 0.15rem;
}
.form-control::placeholder {
  color: #495057;
  opacity: 1;
}
.form-control:hover{
    border: 3px solid red;
            }
</style>
<head>
    <!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body>


<ul>
    <li class=logo></li>
  <li><a  href="addcat.php">Add Food Categoey</a></li>
  <li><a href="additem.php">Add Food Item</a></li>
  <li><a href="juicecat.php">Add Drink Category</a></li>
  <li><a href="adddrink.php">Add Drink Item</a></li>
  <li><a href="aorder.php">Order</a></li>
  <li><a href="index1.php">Logout</a></li>

</ul>
      
      <div class=x></div>
        <div class=z>
        <center><h2>Drink Category</h2></center>

            
            <form action="#" method="post" enctype= "multipart/form-data"><br><br><br>

            <center>
            
                <table class=v><tr>
                    <td><label for="category" class="form-label"><h3>Category:</h3></label></td>
                    <td> <input type="text" class="form-control"   name='t1' style="width:250px;"></td>
                </tr>
                <tr>
                    <td> <label for="image" class="form-label"><h3>Image:</h3></label></td>
                    <td class=m><input type="file" class="form-control"  name='t2'> </td>
                </tr>
                <tr>
                    <td> <label  class="form-label"><h3>Discription:</h3></label></td>
                    <td><input type="text" class="form-control" name='t3'> </td>
                </tr>
                <tr>
                    <td>  <input type="submit" value="Submit" class=n></td>
                </tr>
            </table></center>
</form>  
</div></div>
  
<?php
if(isset($_POST['t1'])){
$b=$_FILES['t2']['name'];
$tmp=$_FILES['t2']['tmp_name'];
$a=$_POST['t1'];
$c=$_POST['t3'];
if(move_uploaded_file($tmp,$b))
{   $con=mysqli_connect('localhost','root','','ashoka');
    $q="insert into juicecat value('$b','$a','$c')";
    $rs=mysqli_query($con,$q);
    if($rs)
    {
    echo"<script>window.location='adddrink.php'</script>";
    }
    else{
        echo"error";
    }
}
else{
    echo"error file uploading";
}}
?>
  </body>
</html>