<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<style>
    .flex{display:flex;}
    .detail{
        margin-left:150px;
        margin-top:50px;

    }
    </style>
<body>

<?php

 session_start();
 $b=$_GET['id'];
$con=mysqli_connect('localhost','root','','ashoka');
 $q="select * from fooditem where foodname='$b'";
 $rs=mysqli_query($con,$q);
 while($row=mysqli_fetch_array($rs))
 {
    echo"
  <div class=flex>
  <div><a href='fooditem.php?id=$row[category]' class='btn btn-warning' style='margin-left:100px; margin-top:40px;'>Back to Food List</a>
  <div> <img src='assets/imgs/$row[image]' style='height:350px; margin-left:100px; margin-top:0px;  width:400px;'></div></div>
        
        <div class=detail ><h3 style='text-decoration:underline;font-size:50px;'>$row[foodname]</h3><br>
        <h3>$row[quantity]</h3><hr>
        
  <p style='font-size:25px;'>Discription:$row[description]</p><hr>
  
  <p style='font-size:25px;'><b>Price-:$row[amount]RS/-</b></p><hr>
  

  <a href='mycart.php?id=$row[foodname]&price=$row[amount]' class='btn btn-info'>Add To Cart</a>
          <a href='orderdummy.php?id=$row[foodname]&price=$row[amount]&img=$row[image]' class='btn btn-success'>Order</a><br><br>
  </div>
  </div>

  ";} 
  ?>


</body>
</html>