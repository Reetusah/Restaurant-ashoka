<html>
    <style>
        body{background-image:url('food.jpg');
        background-repeat:no-repeat;
        position:fixed;
    background-size:100% 100%;}
        .flex{
  float:left;
  margin-left:110px;
}
.button{background-color:rgb(22, 176, 22);
    color:white;
    border-radius:5px;
    border-color:rgb(22, 176, 22);
    font-size:15px;
    height:40px;
    width:100px;

}
.button1{background-color:rgb(59, 174, 228);
    color:white;
    border-radius:5px;
    border-color:rgb(59, 174, 228);
    font-size:17px;
    height:40px;
    width:100px;

}
        </style>
    <body>
<center><h1 style="margin-left:500px;">ADD FOOD</h1></center>
<?php
 session_start();

$a=$_GET['id'];
$b=$_GET['price'];

$con=mysqli_connect('localhost','root','','ashoka');
    $q="insert into dummycart value('$a',$b)";
    $rs=mysqli_query($con,$q);
    if($rs)
    {
        echo"save";}
    else{
        echo"error";
    }
    ?></body>
    <?php
    $con=mysqli_connect('localhost','root','','ashoka');
    $q="select * from dummycart ";
    $rs=mysqli_query($con,$q);
    while($row=mysqli_fetch_array($rs))
    {
       echo"<p style='font-size:20px;'>$row[foodname] $row[amount] </p>";
    }
    
    
    ?><br><br>
    <center><a href="index1.php"><input type=submit value="Add Food" class=button1 style="margin-left:500px;"></a>
    <a href="cart.php"><input type=submit value="Buy" class=button></a></center>


 
    