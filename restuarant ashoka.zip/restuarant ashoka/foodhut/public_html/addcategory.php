<html>
  <style>
    
    body{
background-image:url("a6.jpeg");
background-size:1700px 800px;
background-repeat:no-repeat;}

.nav{
                font-size:22px;
                
                }
                li{
            float:left;
        }
        li a{
        
            color:white;
            text-align:center;
            padding:0px 10px;
            text-decoration:none;
        }
        li a:hover{
            text-decoration:underline;
            color:red;}
            
        
        .logo{width:50px;
    height:50px; background-image:url('logo.jpg');
    background-size: 50px 50px;
    border-radius: 360px;
    margin-left: 5px;
    margin-top: 5px;}
        .nav{float:left;
        padding:10px;font-size:20px;
        
        
    }

.x{position:absolute;
background-color:black;
box-shadow:3px 5px 8px 10px white;
float:left;
width:500px;
height:400px;
top:130px;
left:350px;
opacity:0.6;}
.y{position:absolute;
width:300px;
height:400px;
top:0px;
left:450px;
}
.t{color:black;
font-size:40px;
font-family: cursive;


margin-left:350px;
margin-top:10px;
padding:10px 100px;
}
.s{
    color:black;
    font-size: 25px;
    font-family: cursive;
    margin-left:350px;
}
.w{
width:250px;
color:white;
font-size:20px;
background:transparent;
border:none;
border-bottom-style:solid;
border-bottom-color:black;
border-bottom-width:5px;
margin-left:300px;
margin-top:10px;}
.fc{
    margin-left:40px;
     margin-top:150px;
    color:white;
    font-family:cursive ;
    font-size:29px;
}
.p{

    margin-left: 350px;
}

           
.v{
color:white;
font-weight:bold;}
.n{
    background-color: red;
    color:white;
    border-radius:10px;
    height:50px;
    width:100px;
    font-size:15px;
}
.m{color:black;}
.form-control {
  display: block;
  width: 100%;
  height: calc(1.5em + 0.8rem + 2px);
  padding: 0.4rem 0.78rem;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  color:black;
  background-color: white;
  background-clip: padding-box;
  border: 1px solid #495057;
  border-radius: 0.2rem;
  -webkit-transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}


  .form-control {
    -webkit-transition: none;
    transition: none;
  }
  .form-control-lg {
  height: calc(1.5em + 1.6rem + 2px);
  padding: 0.8rem 1.6rem;
  font-size: 1.25rem;
  line-height: 1.5;
  border-radius: 0.15rem;
}
.form-control::placeholder {
  color: #495057;
  opacity: 1;
}
.form-control:hover{
    border: 3px solid red;
            }
</style>
<head>
    <!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body>

<ul>
    <a href="#"> <li class=logo></a></li>
        <li class="nav"><a href="addcategory.php" style="text-decoration:underline;">Add Categoey</a></li>
        <li class="nav"><a href="additem.php" style="text-decoration:underline;">Add Fooditem </a></li>
        <li class="nav"><a href="adddrink.php" style="text-decoration:underline;margin-left:350px;">Add Juice</a></li>

        <li class="nav"><a href="order.php" style="text-decoration:underline;">Order</a></li>
        <li class="nav"><a href="index1.php" style="text-decoration:underline;">Logout</a></li>
        
        </ul>

      
      <div class=x></div>
        <div class=y>
            <p class="fc">FOOD CATEGORY</p>
            <form action="#" method="post" enctype= "multipart/form-data"><br><br><br>

            <center>
            
                <table class=v><tr>
                    <td><label for="category" class="form-label"><h3>Category:</h3></label></td>
                    <td> <input type="text" class="form-control"   name='t1'></td>
                </tr>
                <tr>
                    <td> <label for="image" class="form-label"><h3>Image:</h3></label></td>
                    <td class=m><input type="file" class="form-control"  name='t2'> </td>
                </tr>
                <tr>
                    <td> <label  class="form-label"><h3>Discription:</h3></label></td>
                    <td><input type="text" class="form-control" name='t3'> </td>
                </tr>
                <tr>
                    <td>  <input type="submit" value="Submit" class=n></td>
                </tr>
            </table></center>
</form>  
</div></div>
  
<?php
if(isset($_POST['t1'])){

$b=$_FILES['t2']['name'];
$tmp=$_FILES['t2']['tmp_name'];
$a=$_POST['t1'];
$c=$_POST['t3'];


if(move_uploaded_file($tmp,$b))
{
    $con=mysqli_connect('localhost','root','','ashoka');
    $q="insert into category value('$b','$a','$c')";
    $rs=mysqli_query($con,$q);
    if($rs)
    {
    echo"<script>window.location='additem.php'</script>";
    }
    else{
        echo"error";
    }
}
else{
    echo"error file uploading";
}}
?>
  
  


    

</body>
</html>