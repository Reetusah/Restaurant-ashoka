<?php
$a=$_GET['t1'];
$b=$_GET['t2'];
$conn=mysqli_connect('localhost','root','','ashoka');
$q="update dummycart where foodname='$a'";

$rs=mysqli_query($conn,$q);

if($rs)
{
    echo"update";
}
else
{
    echo"error";
}
?>