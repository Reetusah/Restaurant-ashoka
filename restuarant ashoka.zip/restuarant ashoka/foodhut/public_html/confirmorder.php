<html>
    <style>
        .button{background-color:red;
    color:white;
    border-radius:10px;
    border-color:red;
    font-size:17px;
    height:40px;
    width:150px;
}
       .i{height:180px;
    width:180px;
margin-top:80px;}
        </style>
<body>
    <center><img src='o.png' class=i>
<h2>Super! Your order hase been confirmed.</h2>
<a href="index1.php"><input type=submit value=Done class=button></a>
</center>
</body>
</html>