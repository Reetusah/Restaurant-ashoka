<?php
$a=$_GET['id'];

$conn=mysqli_connect('localhost','root','','ashoka');
$q="update orderinfo1 set action=0  where action='$a'";

$rs=mysqli_query($conn,$q);

if($rs)
{
    echo"<script>window.location='aorder.php'</script>";
}
else
{
    echo"error";
}
?>