<html>
  <style>
    
    body{
background-image:url("bac.jpg");
background-size:1700px 800px;
background-repeat:no-repeat;}

.x{position:absolute;
background-color:black;
box-shadow:3px 5px 8px 10px white;
float:left;
width:600px;
height:450px;
top:90px;
left:300px;
opacity:0.6;}
.y{position:absolute;
width:300px;
height:400px;
top:0px;
left:450px;
}
.t{color:black;
font-size:40px;
font-family: cursive;


margin-left:350px;
margin-top:10px;
padding:10px 100px;
}
.s{
    color:black;
    font-size: 25px;
    font-family: cursive;
    margin-left:350px;
}
.w{
width:250px;
color:white;
font-size:20px;
background:transparent;
border:none;
border-bottom-style:solid;
border-bottom-color:black;
border-bottom-width:5px;
margin-left:300px;
margin-top:10px;}
.fc{
    margin-left:40px;
     margin-top:150px;
    color:white;
    font-family:cursive ;
    font-size:29px;
}
.p{

    margin-left: 350px;
}

            .nav{
                font-size:22px;
                }
                li{
            float:left;
        }
        li a{
            display:block;
            color:white;
            text-align:center;
            padding:14px 16px;
            text-decoration:none;
        }
        li a:hover{
            text-decoration:underline;
            color:red;}
            
        
        .logo{width:50px;
    height:50px; background-image:url('logo.jpg');
    background-size: 50px 50px;
    border-radius: 360px;
    margin-left: 5px;
    margin-top: 10px;}
.v{
color:white;
font-weight:bold;}
.n{
    background-color: red;
    color:white;
    border-radius:10px;
    height:50px;
    width:100px;
    font-size:15px;
}
.m{color:black;}
</style>
<head>
    <!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body>


      <div></div>
      <div class=x></div>
        <div class=y>
            <p class="fc">Admin Login Page</p>
            <form action="#" method="GET" enctype= "multipart/form-data"><br><br>

            <center><table class=v>
                <tr>
                    <td> Email:</td>
                    <td> <input type="text" class="form-control"   name='t1'></td>
                </tr>
                <tr>
                    <td>Password:</td>
                    <td class=m><input type="text" class="form-control"  name='t2'> </td>
                </tr>
                
                    
                    <td>  <input type="submit" value="Login" class=n></td>
                </tr>
            </table></center>
</form>  
</div></div>

<?php

if(isset($_GET['t1'])){
$a=$_GET['t1'];
$b=$_GET['t2'];



$conn=mysqli_connect('localhost','root','','bloodbank');
$q="select * from adminlogin where email='$a' and password='$b'";
$rs=mysqli_query($conn,$q);
if($rs=mysqli_fetch_array($rs))
{
  
    echo"<script>window.location='addcat.php'</script>";
}
else{
    echo"<center><h3>please enter correct email or password!!</h3></center>";
}}
?>

</body>
</html>