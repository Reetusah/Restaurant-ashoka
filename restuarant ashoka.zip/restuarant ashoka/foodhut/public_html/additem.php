<html>
  <style>
    
    body{
background-image:url("bac.jpg");
background-size:1700px 800px;
background-repeat:no-repeat;}

.x{position:absolute;
background-color:black;
box-shadow:3px 5px 8px 10px white;
float:left;
width:600px;
height:450px;
top:100px;
left:300px;
opacity:0.6;}
.z{position:absolute;
    color:white;
width:300px;
height:0px;
top:120px;
left:420px;}



.fc{height:50px;
    margin-left:40px;
     margin-top:100px;
    color:white;
    font-family:cursive ;
    font-size:29px;
    
}

ul {background-color:rgb(46, 43, 43);
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  
}



li {
  float: left;
}

li a {
  display: block;
  color: white;
  font-size:20px;
 padding:25px 0px;
  text-decoration: none;
  margin-left:30px;
  text-decoration:underline;
}

li a:hover {
  
  color:rgb(223, 52, 86);
}
            
        
.logo{width:50px;
    height:50px; background-image:url('logo.jpg');
    background-size: 50px 50px;
    border-radius: 360px;
    margin-left: 5px;
    margin-top: 10px;}
    .v{
color:white;
font-weight:bold;}
.n{
    background-color: red;
    color:white;
    border-radius:10px;
    height:50px;
    width:100px;
    font-size:15px;
}

.form-control:hover{
    border: 3px solid red;
            }
            
</style>
<head>
    <!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body>

<ul>
    <li class=logo></li>
  <li><a  href="addcat.php">Add Food Category</a></li>
  <li><a href="additem.php">Add Food Item</a></li>
  <li><a href="juicecat.php">Add Juice Category</a></li>
  <li><a href="adddrink.php">Add Juice Item</a></li>
  <li><a href="aorder.php">Order</a></li>
  <li><a href="index1.php">Logout</a></li>

</ul>


      
      <div class=x></div>
        <div class=z style="width:300px;height:300px;">
        <center><h1>FOOD ITEM</h1></center>
            <form action="#" method="post" enctype= "multipart/form-data"><br><br><br>

            <center><table class=v>
                
                <tr>
                    <td> <label for="image" class="form-label"><h4>Image:</h4></label></td>
                    <td ><input type="file" class="form-control"  name='t1' style="width:250px;"> </td>
                </tr>
                <tr>
                    <td> <label  class="form-label"><h4>Foodname:</h4></label></td>
                    <td><input type="text" class="form-control" name='t2'> </td>
                </tr>
                <tr>
                    <td> <label  class="form-label"><h4>Discription:</h4></label></td>
                    <td><input type="text" class="form-control" name='t3'> </td>
                </tr>
                <tr>
            
                    <td><label for="category" class="form-label"><h4>category:</h4></label></td>
                    <td><select  class="form-control"   name='t4'><option>Egg Crispy</option>
                <option>Chiken Biryani</option>
                <option>Dessert</option>
                
            </select>
                     </td>
                </tr>
                <tr>
                    <td> <label  class="form-label"><h3>Quantity:</h3></label></td>
                    <td><input type="text" class="form-control" name='t6'> </td>
                </tr>
                <tr>
                    <td> <label  class="form-label"><h3>Amount:</h3></label></td>
                    <td><input type="text" class="form-control" name='t5'> </td>
                </tr>
                <tr>
                    <td>  <input type="submit" value="Submit" class=n></td>
                </tr>
            </table></center>
        </form>  
</div></div>
  



<?php
 
if(isset($_POST['t2'])){

$a=$_FILES['t1']['name'];
$tmp=$_FILES['t1']['tmp_name'];
$b=$_POST['t2'];
$c=$_POST['t3'];
$d=$_POST['t4'];
$e=$_POST['t5'];
$f=$_POST['t6'];
if(move_uploaded_file($tmp,$a))
{

    $conn=mysqli_connect('localhost','root','','ashoka');
    $q="select * from fooditem where image='$a' and foodname='$b'";
    $rs=mysqli_query($conn,$q);
    if($row=mysqli_fetch_array($rs))
    {
        echo"<center><p style='color:white;'>Note-This Food already entered!!<p><center>";
    }
    else{
    $q="insert into fooditem value('$a','$b','$c','$d','$e','$f')";

    $rs=mysqli_query($conn,$q);
    if($rs)
    {
        echo"<script>window.location='adddrink.php'</script>";
    }
    else{
        echo"error";
    }
}
}}

?>
  


    

</body>
</html>