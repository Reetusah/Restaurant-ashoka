<html>
  <style>
   ul {background-color:rgb(46, 43, 43);
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  
}
li {
  float: left;
}

li a {
  display: block;
  color: white;
  font-size:20px;
 padding: 25px 0px;
  text-decoration: none;
  margin-left:30px;
  text-decoration:underline;
}

li a:hover {
  
  color:rgb(223, 52, 86);
}
            
        
.logo{width:50px;
    height:50px; background-image:url('logo.jpg');
    background-size: 50px 50px;
    border-radius: 360px;
    margin-left: 5px;
    margin-top: 10px;}
    table {
  border-collapse: collapse;
  width: 80%;
}

th, td {
  padding: 10px;
  font-size:17px;
  text-align: left;
  border-bottom: 3px solid ;
}
.delete{
  background-color:red;
  border-radius:5px;
  border-color:red;

  height:30px;
  width:100px:
  

}

th,td:hover {background-color:;}
  </style>
  <body>
  <ul>
  <li class=logo></li>
<li><a  href="addcat.php">Add Food Categoey</a></li>
<li><a href="additem.php">Add Food Item</a></li>
<li><a href="juicecat.php">Add Drink Category</a></li>
<li><a href="adddrink.php">Add Drink Item</a></li>
<li><a href="aorder.php">Order</a></li>
<li><a href="index1.php">Logout</a></li>

</ul>
<center><h2 style="text-decoration:underline;">List of Customer Order</h2></center>
<?php
    echo"<center>
    <table><tr>
    <th>S.No</th>
    <th>Name</th>
    <th>Mobile No</th>
    <th>Food Name</th>
    <th>Amount</th>
    <th>Action</th></tr></center>";
$conn=mysqli_connect('localhost','root','','ashoka');
$q="select * from orderinfo1 where action=0";
$rs=mysqli_query($conn,$q);
while($row=mysqli_fetch_array($rs))
{
    echo"<center><tr>
        <td>$row[sno]</td>
        <td>$row[name]</td>
        <td>$row[mobile]</td>
        <td>$row[foodname]</td>
        <td>$row[amount]</td>
    
<td><a href='orderdelete.php?id=$row[sno]'><input type=submit value=Delete class=delete style=color:white;></a></a></td>
    </tr></center>";
}
echo"</table>";

?>
  </body>
  </html>