<?php

 session_start();
$a=$_POST['t1'];
$b=$_POST['t2'];
$con=mysqli_connect('localhost','root','','ashoka');
$q="select * from dummycart ";
    $rs=mysqli_query($con,$q);
    while($row=mysqli_fetch_array($rs))
    {
        echo"<p style='font-size:20px;'>$row[foodname] $row[amount]<span>
    
        <a href='delete.php?id=$row[foodname]'><input type=submit value=Delete class=button></a></span></p></p>";

        $q2="insert into orderinfo1 value('null','$a','$b','$row[foodname]','$row[amount]','1')";
        $rs2=mysqli_query($con,$q2);
   }
   if($rs)
   {
       echo"<script>window.location='confirmorder.php'</script>";
   }
       
       else{echo"error";}

   ?>