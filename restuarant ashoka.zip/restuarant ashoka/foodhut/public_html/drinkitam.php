 <html>
    <style>
.flex{
  float:left;
  margin-left:110px;
}
.button{background-color:rgb(22, 176, 22);
    color:white;
    border-radius:5px;
    border-color:rgb(22, 176, 22);
    font-size:15px;
    height:30px;
    width:95px;

}
.button1{background-color:rgb(59, 174, 228);
    color:white;
    border-radius:5px;
    border-color:rgb(59, 174, 228);
    font-size:17px;
    height:30px;
    width:90px;

}
</style>
 <body>
  <center><h2>List of Drink Item</h2></center>
<?php
 $d=$_GET['id'];
 $con=mysqli_connect('localhost','root','','ashoka');
 $q="select * from juiceitem where category='$d'";
 $rs=mysqli_query($con,$q);
 
 while($row=mysqli_fetch_array($rs))
 {
    echo"<div class='flex' style='margin-top:50px;'>
    <div class='card' style='width:250px'><a href='fooddetail.php?id=$row[name]'>
         <img class='card-img-top' src='assets/imgs/$row[image]'alt='$row[name]' class='rounded-0 card-img-top mg-responsive' style='height:170px;'></a>
         <div class='card-body'>
         <p>$row[category]</p>
         <h3>$row[name]</h3>
         <h2>$row[amount]RS/-</h2>

         <a href='drinkorder.php?id=$row[name]'><input type=submit value='Order Now' class='button'></a>
           <a href='juicedetail.php?id=$row[name]'><input type=submit value='Detail' class='button1'></a><hr>
           
       </div>
     </div></div>
     ";}

     ?>
     </body>
     </html>

    