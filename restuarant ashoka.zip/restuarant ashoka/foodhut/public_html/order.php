<html>
    <style>
        .text{
            height:40px;width:210px;
            padding:10px;
            }
            .find{
            background-color:green;
            border-radius:6px;
            border-color:green;
            height:40px;
            width:150px;
            color:white;
            margin-left:20px;
            font-size:15px;}
            .text:hover{
    border: 3px solid rgb(180, 43, 43);
            }
            .find:hover{
                background-color:rgb(180, 43, 43);
            }
            .back{
                background-color:rgb(167, 167, 61);
                border-radius:6px;
            border-color:rgb(167, 167, 61);
            height:40px;
            width:150px;
            color:white;
            font-size:15px;}
            
        </style>
<body>

<?php
 $b=$_GET['id'];
$con=mysqli_connect('localhost','root','','ashoka');
 $q="select * from fooditem where foodname='$b'";
 $rs=mysqli_query($con,$q);
 while($row=mysqli_fetch_array($rs))
 {
    echo"
  <div>
  <div><a href='fooddetail.php?id=$row[foodname]'><input type=submit value='Back to Food List' class=back></a>
  <center><div> <img src='assets/imgs/$row[image]' style='height:200px; margin-top:0px;  width:300px;'></div></div>
        
        <center><div><h3>$row[foodname]</h3>
  <p>1 Item Selected!</p>
  <p style='font-size:25px;'><b>RS-:$row[amount]RS/-</b></p></center>
  
  </div>
  </div>

  ";} 
  ?>

<center>
<form action="savedata1.php" mathod=GET>
Name:<input type=text placeholder="Name" class=text name=t1>
    Mobile no:<input type=text placeholder="Mobile No." name=t2 class=text>
    <a href=confirmorder.php><input type=submit  value="Confirm Order" class=find></a></center><br><br><br><br><br><hr>
 </form>

 


 
</body>
</html>