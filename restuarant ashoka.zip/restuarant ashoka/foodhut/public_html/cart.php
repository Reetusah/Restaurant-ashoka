<html>
<style>
  
       body{background-image:url('food.jpg');
        background-repeat:no-repeat;
        width:100%;
        height:200%;
        position:fixed;
        background-size:100% 200%;}
  .text{
            height:40px;width:210px;
            padding:10px;
            
            }
            .text:hover{border-color: red;}
   .button{background-color:red;
    color:white;
    border-radius:10px;
    border-color:red;
    font-size:15px;
    height:40px;
    width:100px;
}
.button1{background-color:rgb(22, 176, 22);
    color:white;
    border-radius:5px;
    border-color:rgb(22, 176, 22);
    font-size:15px;
    height:40px;
    width:140px;

}
</style>



<?php

 session_start();

$con=mysqli_connect('localhost','root','','ashoka');
    $q="select * from dummycart ";
    $sum=0;
    $rs=mysqli_query($con,$q);
    while($row=mysqli_fetch_array($rs))
    {
      echo"<p style='font-size:20px;'>$row[foodname] $row[amount]<span>
    
      <a href='delete.php?id=$row[foodname]'><input type=submit value=Delete class=button></a></span></p></p>";
      $sum=$row['amount']+$sum;

   }
   echo"<h2>Total amount= $sum</h2>";

    ?>

    <form action=savedata.php method="POST">
    <span style="padding:50px;font-size:24px;">Name:<input type=text name=t1 class=text></span>
    <span style="padding:50px;font-size:24px;">Mobile no:<input type=text name=t2 class=text></span>
    <input type=submit value="Confirm Order" class=button1>
</form>


